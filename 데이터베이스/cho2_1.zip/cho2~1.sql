create table member(
    id varchar2(20),
    pwd varchar2(20) not null,
    name varchar2(20) not null,
    zipcode varchar2(20) not null,
    address1 varchar2(200) not null,
    address2 varchar2(60) not null,
    tel varchar2(15) not null,
    indate date default sysdate,
    constraint member_pk primary key(id)
);

create table admin_mem(
    adminid varchar2(20),
    pwd varchar2(20) not null,
    name varchar2(30),
    tel varchar2(15),
    constraint admin_mem_pk primary key(adminid)
);

create table products(
    product_code varchar2(20),
    product_name varchar2(100),
    product_kind char(1),
    product_price1 number,
    product_price2 number,
    product_content varchar2(1000),
    product_image varchar2(50),
    sizeSt number,
    sizeEd number,
    product_quantity varchar2(5),
    useyn char(1),
    indate date default sysdate,
    adminid varchar2(20),
    constraint product_code_pk primary key(product_code),
    constraint product_adminid_fk foreign key(adminid) 
    references admin_mem(adminid)    
);

create table orders(
    order_seq number(10)constraint orders_seq_pk primary key,
    product_code varchar2(20) not null ,
    id varchar2(20)not null,
    product_size number not null,
    quantity number not null,
    result char(1),
    indate date default sysdate,
    constraint orders_code_fk foreign key(product_code)
    references products(product_code),
    constraint orders_id_fk foreign key(id) 
    references member(id)
);

insert into admin_mem(adminid,pwd,name)
values('aduser1','dit20','ȫ�浿');
insert into member(id,pwd,name,zipcode,address1,address2,tel)
values('one','1111','���ϵ�','15761','����� ���α� ����1�� �ְ�����Ʈ','104-1004ȣ','010-111-1111');
insert into products(product_code,product_name,product_kind,product_price1,product_price2,product_content,sizest,sizeed,product_quantity,adminid)
values('hi0001','ȸ����','1',10000,12000,'�������� ��', 230, 255,'100','aduser1');

create SEQUENCE ORDER_SEQ
start with 1
increment by 1
maxvalue 100000;

insert into orders(order_seq, product_code,id,product_size,quantity)
values(order_seq.nextval,'hi0001', 'one',230,'5');

select od.order_seq,od.product_code,pr.product_name,od.id,me.name,od.quantity,od.indate
from orders od, member me, products pr
where od.product_code=pr.product_code
and od.id=me.id;
