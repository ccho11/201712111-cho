create table member(
    memberid varchar2(10) PRIMARY KEY,
    membername varchar2(20) not null,
    phone varchar2(15),
    email varchar2(30)
);

create table m_order(
    orderid number primary key,
    memberid varchar2(10),
    orderdate date,
    foreign key(memberid) references member
);

alter table m_order
modify memberid not null;

alter table m_order
modify orderdate date default sysdate not null;

insert into member(memberid, membername)
values('hong1','ȫ�浿');
insert into member(memberid, membername)
values('hong2','ȫ���');
insert into member(memberid, membername)
values('kim1','��浿');

select * from member;

insert into m_order(orderid, memberid)
values(1, 'hong2');
insert into m_order(orderid, memberid)
values(2, 'kim1');

select * from m_order;

update member
set phone='000-1111-1112'
where memberid='hong2';
