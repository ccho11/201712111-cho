grant select, update on customer to cho1;

grant connect, resource to cho1;

grant select on cho1.m_order to cho1;

revoke update on customer from cho1;

revoke create session from dituset1;

create user aa1
identified by ditdb20;

create user aa2
identified by ditdb20;

grant connect, resource to aa1;

grant create session to aa2;
grant select on book to cho1;



