drop table dept_second;
drop table dept_third;

create table dept_second(
    dno number(2) constraint pk_dept_second primary key,
    dname varchar2(14),
    loc varchar(13)
);

create table Customer1(
    id VARCHAR2(20) CONSTRAINT customer1_id_pk PRIMARY KEY,
    pwd VARCHAR2(20) CONSTRAINT customer1_id_nn NOT NULL, 
    name VARCHAR2(20) CONSTRAINT customer1_id_nn NOT NULL,
    phone VARCHAR2(30),
    address VARCHAR2(100)
);

insert into customer1
values('greentea', '1234', '�����ư���', '010-111-1111', 'seoul');

insert into customer1
values(null, '1234', '�����ư���', '010-111-1111', 'seoul');


SELECT * FROM customer1;

drop table customer1;

create table emp_second(
    eno number CONSTRAINT emp_second_eno_pk primary key,
    ename VARCHAR2(10),
    job VARCHAR2(9),
    dno number CONSTRAINT emp_second_dno_fk REFERENCES department
);

create table emp_third(
    eno NUMBER CONSTRAINT emp_third_eno_pk PRIMARY KEY,
    ename VARCHAR2(10),
    salary NUMBER(7,2) DEFAULT 1000
    CONSTRAINT emp_third_salary_min check(salary>0)
);

CREATE TABLE emp_copy
as
SELECT
    *
FROM employee;

create table dept_copy
as
SELECT
    *
FROM department;

select table_name, constraint_name
from user_constraints
where table_name in('EMPLOYEE', 'DEPARTMENT');

alter table emp_copy
add CONSTRAINT emp_copy_eno_pk primary key(eno);

alter table dept_copy
add CONSTRAINT dept_copy_dno_pk primary key(dno);

alter table emp_copy
add CONSTRAINT emp_copy_dno_fk
foreign key(dno) REFERENCES dept_copy(dno);

select table_name, constraint_name
from user_constraints
where table_name in('EMP_COPY', 'DEPT_COPY');

alter table dept_copy
drop primary key cascade;

insert into emp_copy(eno, ename, dno)
values(8000, '����ȭ', 50);

alter table emp_copy
disable constraint emp_copy_dno_fk;

select table_name, constraint_name, status
from user_constraints
where table_name in('EMP_COPY', 'DEPT_COPY');

create table emp_sample
as
select * from employee
where 1=0;

alter table emp_sample
add constraint emp_sample_eno_pk primary key(eno);

alter table emp_sample
add foreign key(dno) REFERENCES department(dno);

select * from emp_sample;

insert into emp_sample(eno, ename, dno)
values(1,'ȫ�浿',10);

insert into emp_sample(eno, ename, dno)
values(2,'1�浿',40);
insert into emp_sample(eno, ename, dno)
values(3,'qkr�浿',50);

select table_name, constraint_name,status
from user_constraints
where table_name ='EMP_SAMPLE';

alter table emp_sample
disable constraint sys_c007058;

create sequence sample_seq
start with 10
INCREMENT by 10;

create table dept_copy1
as
select * from department where 0=1;

insert into dept_copy1
values(sample_seq.nextval, 'ACCOUNTING','NEW YORK');

insert into dept_copy1
values(sample_seq.nextval, 'SALES','CHICAGO');

select * from dept_copy1;

drop sequence smaple_seq;

create table dept_copy2
as
select * from department where 0=1;

insert into dept_copy2
values(10,'ACCOUNTING','NEW YORK');

create table emp_copy1
as
select eno, ename, job, hiredate, dno from employee where 0=1;

insert into emp_copy1
values(7000,'CANDY','MANAGER','2012/05/01',10);

insert into emp_copy1
values(7020,'JERRY','SALESMAN',SYSDATE,30);

select * from emp_copy1;

update dept_copy2
set dname='PROGRAMMING'
where dno = 10;

update dept_copy2
set dname='HR';

update dept_copy2
set dname='PROGRAMMING', loc='SEOUL'
where dno=10;

delete dept_copy2
where dno=10;

select * from dept_copy2;

create table dept_cp
as
select * from department;

select * from dept_cp;

delete dept_cp;

ROLLBACK;

delete dept_cp
where dno=10;

COMMIT;
ROLLBACK;

