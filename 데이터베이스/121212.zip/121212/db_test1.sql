select * from book
where bookname like '%�౸%';

create view vw_book
as select * from book
where bookname like '%�౸%';

select * from vw_book;

select * from customer
where address like '%���ѹα�%';

create view vw_customer
as select * from customer
where address like '%���ѹα�%';

select * from vw_customer;

select *from customer;

insert into vw_customer
values(7,'�迬��','���ѹα� ����','000-1212-0001');

create view vw_orders(orderid, custid, name, bookid,bookname,saleprice,orderdate)
as select od.orderid, od.custid, cu.name, od.bookid,bk.bookname, od.saleprice, od.orderdate
from orders od, customer cu, book bk
where od.custid=cu.custid and od.bookid=bk.bookid;

select * from vw_orders;

select orderid,bookname,saleprice
from vw_orders
where name = '�迬��';

create view vw_orders3
as select od.bookid,bk.bookname,sum(od.saleprice) "tot_sum",
round(avg(od.saleprice),0)"tot_avg"
from orders od, book bk
where od.bookid=bk.bookid
group by od.bookid, bk.bookname
order by od.bookid;

select * from vw_orders2;

create view vw_orders3
as select bk.bookname,bk.bookid,sum(od.saleprice) "tot_sum",
round(avg(od.saleprice),0)"tot_avg"
from book bk left outer join orders od
on od.bookid=bk.bookid
group by od.bookid,bk.bookname,bk.bookid
order by bk.bookname;

select * from vw_orders3;

create view vw_orders4
as select bk.bookname, bk.bookid,
nvl(sum(od.saleprice),0)"tot_sum",
nvl(round(avg(saleprice),0),0)"tot_avg"
from book bk left outer join orders od
on od.bookid=bk.bookid
group by od.bookid, bk.bookname, bk.bookid
order by bk.bookid;

select * from vw_orders4;

create or replace view vw_customer(custid,name,address)
as select custid, name, address
from customer
where address like '%����%';

select * from vw_customer;

select bk.bookid,bk.bookname,cu.name,bk.publisher,bk.saleprice
from orders od,customer cu,book bk
where bk.saleprice >= 20000;

create view highorders
as select bk.bookid,bk.bookname,cu.name,bk.publisher,od.saleprice
from orders od,customer cu,book bk
where od.saleprice >= 20000 and od.custid=cu.custid and od.bookid=bk.bookid;

select * from highorders;

