create table member(
id varchar2(20) primary key,
pwd varchar2(20) not null,
name varchar2(20) not null,
zipcode varchar2(5) not null,
address1 varchar2(70) not null,
address2 varchar2(40) not null,
tel varchar2(15) not null,
indate date DEFAULT 'sysdate'
);